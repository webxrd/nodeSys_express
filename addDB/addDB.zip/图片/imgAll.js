const liqiu = require('./立秋');// 立秋
const qixi = require('./七夕');// 棒图网图片
const zhuangshihua = require('./装饰画');// 装饰画
const huace = require('./画册');// 画册

module.exports = [
    {colName: "liqiu",list: liqiu},
    {colName: "qixi",list: qixi},
    {colName: "zhuangshihua",list: zhuangshihua},
    {colName: "huace",list: huace}
];